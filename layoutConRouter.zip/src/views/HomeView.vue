<template>
    <h1>Hola soy el index</h1>

</template>