<template>
    <h1>Hola soy el login</h1>
    <form>
        <label for="username"></label>
        <input type="text" id="username" placeholder="username">
        <label for="password"></label>
        <input type="password" id="password" placeholder="password">
    </form>
</template>