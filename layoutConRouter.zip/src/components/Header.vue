<script setup>
import {ref} from "vue"

const emit = defineEmits(["sesionIniciada", "sesionCerrada"])

const props = defineProps({
  title: String,
});

const form = ref({ usuario: '', password: '' });
const usuarioAutenticado = localStorage.getItem("sesion")? ref(JSON.parse(localStorage.getItem("sesion"))): ref(null);
const error = ref('');

async function iniciarSesion() {
  try {
    const response = await fetch('/usuarios.json'); 
    const usuarios = await response.json();

    const usuarioEncontrado = usuarios.find(
      (u) => u.usuario === form.value.usuario && u.password === form.value.password
    );

    if (usuarioEncontrado) {
      usuarioAutenticado.value = {
        usuario: usuarioEncontrado.usuario,
        rol: usuarioEncontrado.rol
      };

      emit("sesionIniciada", usuarioAutenticado.value)
      //TODO: HABRÍA QUE NOTIFICAR A APP.VUE CON UN EMIT PARA QUE SEPA QUE LA SESIÓN ESTÁ INICIADA
      error.value = '';
      localStorage.setItem("sesion", JSON.stringify(usuarioAutenticado.value));
    } else {
      error.value = 'Usuario o contraseña incorrectos';
    }
  } catch (err) {
    error.value = 'Error al cargar los datos';
  }
}
function cerrarSesion() {
  usuarioAutenticado.value = null;
  form.value.usuario = '';
  form.value.password = '';
  localStorage.removeItem("sesion");
  emit("sesionCerrada", null)
//TODO: HABRÍA QUE NOTIFICAR A APP.VUE CON UN EMIT PARA QUE SEPA QUE LA SESIÓN ESTÁ CERRADA

}
</script>


<template>
    <header class="bg-dark text-white  p-3">
      <div class="row">
        <h1 class="col-8">{{ title }}</h1>
        <div class="col-4">
        <div v-if="!usuarioAutenticado" >
          <form @submit.prevent="iniciarSesion" class="d-flex  align-items-center gap-2">
            <input v-model="form.usuario" type="text" class="form-control " placeholder="Usuario" required />
            <input v-model="form.password" type="password" class="form-control " placeholder="Contraseña" required />
            <button type="submit" class="btn btn-success">Iniciar Sesión</button>
          </form>
          <p v-if="error" class="text-danger mt-2">{{ error }}</p>
        </div>
        <div v-else class="container text-end">
          <span>Bienvenido, {{ usuarioAutenticado.usuario }} ({{ usuarioAutenticado.rol }})</span>
          <button @click="cerrarSesion" class="btn btn-danger">Cerrar Sesión</button>
        </div>
      </div>
      </div>
  </header>
</template>
  
 
<style scoped>

</style>
  